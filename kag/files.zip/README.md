# Knowledge Augmented Generator (KAG)

This system enhances LLM responses by incorporating structured information from a knowledge graph.

## Setup

1. Install required dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Download the required Spacy model:
   ```
   python -m spacy download en_core_web_sm
   ```

3. Create a `.env` file in the project root with your Mistral AI API key:
   ```
   MISTRAL_API_KEY=your_api_key_here
   ```

## Usage

### Process a story and ask questions

```python
from knowledge_augmented_generator import KnowledgeAugmentedGenerator

# Initialize the system
kag = KnowledgeAugmentedGenerator()

# Process a story
story_text = "Your story text here..."
kag.process_story_and_build_kg(story_text, "story_id")

# Ask questions
response = kag.generate_response("Your question here?")
print(response)
```

### Use the interactive CLI

```
python interactive_kag.py --story path/to/story.txt
```

Or to load an existing knowledge graph:

```
python interactive_kag.py --csv path/to/knowledge_graph.csv
```

## Components

- `knowledge_graph_generation.py`: Creates knowledge graphs from text
- `knowledge_augmented_generator.py`: Main KAG implementation that uses knowledge graphs to enhance LLM responses
- `interactive_kag.py`: CLI for interactive usage
- `example_usage.py`: Example script demonstrating the system

## How it works

1. The system processes text to build a knowledge graph using entity recognition and relationship extraction
2. When a user asks a question, relevant information is retrieved from the knowledge graph
3. This information is formatted into context that is provided to the Mistral AI LLM
4. The LLM generates a response informed by both the provided knowledge and its general capabilities

## Customization

- Change the LLM model by modifying the `model` parameter in the KnowledgeAugmentedGenerator constructor
- Adjust the knowledge expansion depth with the `expand_depth` parameter
- Tune the response temperature with the `temperature` parameter